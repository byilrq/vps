(function () {
  const loginButton = document.getElementById('loginTrigger');
  const toast = document.getElementById('fakeToast');
  const remember = document.getElementById('rememberToggle');
  const togglePassword = document.getElementById('togglePassword');
  const password = document.getElementById('password');
  const overlay = document.getElementById('overlay');
  const sheet = document.getElementById('actionSheet');
  const sheetTitle = document.getElementById('sheetTitle');
  const sheetSub = document.getElementById('sheetSub');
  const sheetBody = document.getElementById('sheetBody');
  const sheetClose = document.getElementById('sheetClose');

  let toastTimer = null;
  let loginTimer = null;

  const panelMap = {
    search: {
      title: '搜索',
      sub: '最近结果',
      items: [
        ['品牌手册 2026.pdf', '文档 · 今天打开', 'PDF'],
        ['Summer Photos.heic', '照片 · 昨天同步', 'HEIC'],
        ['Archive Backup.zip', '压缩包 · 3 天前', 'ZIP']
      ]
    },
    notify: {
      title: '通知中心',
      sub: '最新提醒',
      items: [
        ['相册同步完成', '共新增 186 张照片', '完成'],
        ['新设备已接入', 'iPhone 已加入同步', '设备'],
        ['安全检查已通过', '未发现异常登录', '正常']
      ]
    },
    upload: {
      title: '上传队列',
      sub: '准备上传',
      items: [
        ['Vacation.mov', '2.4 GB · 等待中', '视频'],
        ['Contracts.pdf', '18.4 MB · 待同步', '文档'],
        ['Product Renders', '86 项 · 队列中', '文件夹']
      ]
    },
    device: {
      title: '设备列表',
      sub: '当前在线',
      items: [
        ['MacBook Pro', '桌面端 · 在线', '主设备'],
        ['iPhone', '移动端 · 在线', '手机在线'],
        ['iPad', '平板端 · 5 分钟前活跃', 'Pad']
      ]
    },
    space: {
      title: '空间概览',
      sub: '存储详情',
      items: [
        ['照片备份', '804 GB · 自动分类', '照片'],
        ['视频素材', '428 GB · 最近增长', '视频'],
        ['文档与压缩包', '312 GB · 可归档', '文档']
      ]
    },
    devices: {
      title: '在线设备',
      sub: '同步状态',
      items: [
        ['MacBook Pro', '最近同步：2 分钟前', '正常'],
        ['iPhone', '最近同步：刚刚', '正常'],
        ['Windows Desktop', '最近同步：12 分钟前', '空闲']
      ]
    },
    security: {
      title: '安全中心',
      sub: '保护状态',
      items: [
        ['二次验证', '已启用 Face ID 与验证码', '开启'],
        ['登录提醒', '新设备登录即时通知', '开启'],
        ['加密保管箱', '敏感文件单独验证', '已锁定']
      ]
    },
    sort: {
      title: '排序方式',
      sub: '当前为最近修改',
      items: [
        ['最近修改', '优先显示新内容', '已选'],
        ['名称排序', '按字母排列', 'A-Z'],
        ['文件大小', '按体积排列', '大小']
      ]
    },
    filter: {
      title: '筛选器',
      sub: '文件范围',
      items: [
        ['仅照片', 'HEIC / JPG / PNG', '图片'],
        ['仅文档', 'PDF / DOCX / XLSX', '文档'],
        ['仅大型文件', '大于 1 GB', '大文件']
      ]
    },
    folder: {
      title: '文件夹',
      sub: '内容预览',
      items: [
        ['封面图.psd', '最后编辑于今天', '设计'],
        ['演示稿.key', '共享给 3 位成员', '演示'],
        ['预算表.xlsx', '最近查看于昨天', '表格']
      ]
    },
    vault: {
      title: '加密保管箱',
      sub: '需要验证',
      items: [
        ['合同归档', '已锁定 · 需要二次确认', '受保护'],
        ['身份证明', '敏感文件独立加密', '受保护'],
        ['税务资料', '访问前将触发验证', '受保护']
      ]
    },
    preview: {
      title: '文件预览',
      sub: '最近查看',
      items: [
        ['第一页摘要', '文档预览已缓存', '预览'],
        ['分享状态', '当前仅自己可见', '私密'],
        ['操作选项', '支持下载与移动', '操作']
      ]
    },
    refresh: {
      title: '活动列表',
      sub: '已刷新',
      items: [
        ['上传完成', 'Contracts.pdf 已同步', '完成'],
        ['同步完成', 'Summer Photos 更新', '完成'],
        ['设备接入', 'iPad 已成功连接', '设备']
      ]
    },
    activity: {
      title: '活动详情',
      sub: '最近记录',
      items: [
        ['相册同步完成', '新增 186 张照片', '记录'],
        ['项目资料更新', '2 个文件被替换', '记录'],
        ['新设备接入', '已完成安全检查', '记录']
      ]
    },
    help: {
      title: '帮助',
      sub: '快速入口',
      items: [
        ['找回密码', '通过已验证设备恢复', '帮助'],
        ['同步问题', '查看网络与设备状态', '帮助'],
        ['安全设置', '修改验证方式', '帮助']
      ]
    },
    faceid: {
      title: 'Face ID',
      sub: '生物验证',
      items: [
        ['面容验证已准备', '请看向设备以继续', '验证'],
        ['受信任设备', '当前设备已记住', '已记住'],
        ['备用方式', '可切换到验证码', '备用']
      ]
    },
    code: {
      title: '验证码',
      sub: '发送到受信任设备',
      items: [
        ['iPhone', '验证码已发送', '6 位'],
        ['MacBook Pro', '也可在桌面端确认', '确认'],
        ['备用邮箱', '可改用邮件验证', '邮件']
      ]
    }
  };

  function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      toast.classList.remove('show');
    }, 1800);
  }

  function renderSheet(key) {
    const panel = panelMap[key] || {
      title: 'CloudBox',
      sub: '操作已准备',
      items: [['当前操作', '界面交互正常响应', '已就绪']]
    };
    sheetTitle.textContent = panel.title;
    sheetSub.textContent = panel.sub;
    sheetBody.innerHTML = panel.items.map(function (item) {
      return '<div class="sheet-item"><div><strong>' + item[0] + '</strong><span>' + item[1] + '</span></div><small class="sheet-badge">' + item[2] + '</small></div>';
    }).join('');
    overlay.classList.add('show');
    sheet.classList.add('show');
    sheet.setAttribute('aria-hidden', 'false');
  }

  function closeSheet() {
    overlay.classList.remove('show');
    sheet.classList.remove('show');
    sheet.setAttribute('aria-hidden', 'true');
  }

  if (overlay) overlay.addEventListener('click', closeSheet);
  if (sheetClose) sheetClose.addEventListener('click', closeSheet);

  if (remember) {
    remember.addEventListener('click', function () {
      remember.classList.toggle('active');
      showToast(remember.classList.contains('active') ? '已记住此设备' : '已取消记住此设备');
    });
  }

  if (togglePassword && password) {
    togglePassword.addEventListener('click', function () {
      const reveal = password.type === 'password';
      password.type = reveal ? 'text' : 'password';
      togglePassword.textContent = reveal ? '隐藏' : '显示';
    });
  }

  document.querySelectorAll('[data-select]').forEach(function (button) {
    button.addEventListener('click', function () {
      let group = null;
      if (button.classList.contains('segment-btn')) group = '.segment-btn';
      if (button.classList.contains('nav-item')) group = '.nav-item';
      if (button.classList.contains('account-pill')) group = '.account-pill';
      if (!group) return;
      document.querySelectorAll(group).forEach(function (item) {
        item.classList.remove('active');
      });
      button.classList.add('active');
    });
  });

  document.querySelectorAll('[data-panel]').forEach(function (button) {
    button.addEventListener('click', function () {
      const key = button.getAttribute('data-panel');
      renderSheet(key);
      const messages = {
        search: '搜索面板已展开',
        notify: '通知中心已展开',
        upload: '上传队列已打开',
        device: '设备列表已打开',
        space: '空间概览已刷新',
        devices: '设备列表已同步',
        security: '安全状态已检查',
        sort: '排序方式已展开',
        filter: '筛选器已展开',
        folder: '文件夹已打开',
        vault: '保管箱已准备验证',
        preview: '文件预览已打开',
        refresh: '活动列表已刷新',
        activity: '活动详情已打开',
        help: '帮助面板已打开',
        faceid: 'Face ID 已唤起',
        code: '验证码面板已打开'
      };
      showToast(messages[key] || '操作已执行');
    });
  });

  if (loginButton) {
    loginButton.addEventListener('click', function () {
      if (loginButton.classList.contains('is-loading')) return;
      loginButton.classList.add('is-loading');
      clearTimeout(loginTimer);
      loginTimer = setTimeout(function () {
        loginButton.classList.remove('is-loading');
        renderSheet('security');
        showToast('验证成功，正在准备你的云盘...');
      }, 1600);
    });
  }
})();
